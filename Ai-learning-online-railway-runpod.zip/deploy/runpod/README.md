# RunPod GPU Worker

Build this image and push it to a container registry, then create a RunPod GPU Pod using that image.

Required environment variables:

- DATABASE_URL — same PostgreSQL database used by the Railway API
- REDIS_URL — optional for future queue integrations; the current worker polls the DB
- SECRET_KEY — same application secret
- STORAGE_DIR — persistent/shared storage path
- CHECKPOINT_DIR — persistent/shared checkpoint path
- TOKENIZER_DIR — persistent/shared tokenizer path
- LOG_DIR — persistent/shared log path
- DEFAULT_DEVICE=GPU

Important: the worker and API must see the same database and persistent dataset/checkpoint storage. For production, use object storage/shared storage rather than relying on a temporary container filesystem.
