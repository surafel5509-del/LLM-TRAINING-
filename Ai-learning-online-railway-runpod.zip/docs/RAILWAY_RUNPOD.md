# Railway + RunPod Deployment

## Architecture

- Railway API: FastAPI service
- Railway Worker: CPU training worker
- Railway Web: React/Vite static frontend
- PostgreSQL: shared production database
- RunPod: optional NVIDIA GPU training worker

## Railway services

Create three services from the same GitHub repository:

1. API — use `deploy/railway/api/Dockerfile` (or root `railway.json`).
2. Worker — use `deploy/railway/worker/Dockerfile`.
3. Web — use `deploy/railway/web/Dockerfile`.

For API and Worker, set the same database and storage environment variables. Attach a persistent volume to both if they share local dataset/checkpoint files; otherwise use shared object storage.

For Web, set `VITE_API_URL` to the public API URL at build time.

## RunPod GPU worker

Build `deploy/runpod/Dockerfile`, push the image to a registry, and create a GPU Pod from that image. Configure the same `DATABASE_URL`, `SECRET_KEY`, and shared storage/object-storage settings used by the Railway services. Set `DEFAULT_DEVICE=GPU`.

The existing worker polls the database for queued jobs, so it can operate independently of the browser.

## Health check

`GET /api/health`

## Important

Do not use ephemeral local storage for datasets/checkpoints in production. Use a persistent Railway volume for a single worker or shared S3-compatible object storage when multiple workers/API instances must access the same files.
